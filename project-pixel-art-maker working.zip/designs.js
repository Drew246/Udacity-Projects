function setGlobalColor(){ 
     CELL_COLOR = this.value;
     
}

function setColor(){
    this.style.backgroundColor = CELL_COLOR;
    
}

function makeGrid() {                  //method accepts user input of height and width

    var gridHeight = document.getElementById('inputHeight').value;
    var gridWidth = document.getElementById('inputWidth').value;
    let grid = document.getElementById("pixelCanvas");

    while(grid.hasChildNodes())
    {
        grid.removeChild(grid.firstChild);   //clears grid
    }
    
    for(let i = 0; i < gridHeight; i++){         //loop that generates grid after receiving values
        let rows = document.createElement("tr");
        rows.id = "row" + i;

        grid.appendChild(rows);
        let row2 = document.getElementById("row" + i);
        
        for (let x = 0; x < gridWidth; x++){
            let cells = document.createElement("td");
            row2.appendChild(cells);
            cells.addEventListener('click', setColor);    //grabs color selection and stores in CELL_COLOR variable
        }
    }
} 

(function submitSize() {   // When size is submitted by the user, calls makeGrid()

    const submitButton = document.getElementById('submitGridSize');
    submitButton.addEventListener('click', makeGrid);

    var colorInput = document.getElementById('colorPicker');
    colorInput.addEventListener('change', setGlobalColor);

    const element = document.getElementById('sizePicker');
    element.addEventListener('submit', event => {
    event.preventDefault();       // stops code from attempting to submit form//
    });
 })();